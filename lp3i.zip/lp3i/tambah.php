<html>
	<head>
		<title>Tambah Data</title>
		
	</head>
	<body>
		<form action="proses_tambah.php" method="POST">
			NIM : <br>
			<input type="text" name="nim"><br>
			Nama : <br>
			<input type="text" name="nama"><br>
			Jenis Kelamin : <br>
			<input type="radio" name="jenis_kelamin" value="L"> L<br>
			<input type="radio" name="jenis_kelamin" value="P"> P<br>
			Email : <br>
			<input type="email" name="email"><br>
			Alamat : <br>
			<input type="text" name="alamat"><br>
			<input type="submit" value="Submit">
		</form>
	</body>
</html>